# Android APK Development Guide

## Creating a 32-bit Android APK for Last.fm Scrobbler

### Option 1: React Native App (Recommended)

Since you want a 32-bit APK for Android 6.0+, I can create a React Native app that wraps the web interface. Here's what we need:

#### Requirements:
- Node.js and React Native CLI
- Android Studio with SDK 23+ (Android 6.0)
- Java Development Kit (JDK)

#### App Features:
- Native Android interface
- Last.fm authentication
- Single track scrobbling
- Playlist management
- Auto-scrobbling with background service
- Notifications for scrobbles
- Offline queue for when network is unavailable

### Option 2: Flutter App

Flutter can create both 32-bit and 64-bit APKs and supports Android 6.0+.

#### Advantages:
- Single codebase for Android and iOS
- Better performance than web-based solutions
- Native-like UI and UX
- Background processing support

### Option 3: Cordova/PhoneGap (Easiest)

Convert the existing web interface into a mobile app using Cordova.

#### Steps:
1. Install Cordova CLI
2. Create new Cordova project
3. Add your HTML/CSS/JS files
4. Configure for Android 6.0+
5. Build APK with 32-bit support

### Implementation Plan

I recommend starting with **Cordova** since we already have the web interface ready:

1. **Package the web interface** into a Cordova app
2. **Add native plugins** for:
   - Background processing
   - Notifications
   - Network status detection
3. **Configure build settings** for:
   - Android 6.0+ compatibility
   - 32-bit architecture support
   - Required permissions

### Build Configuration

For 32-bit support on Android 6.0+:

```xml
<!-- config.xml -->
<platform name="android">
    <preference name="android-minSdkVersion" value="23" />
    <preference name="android-targetSdkVersion" value="33" />
    <preference name="Orientation" value="portrait" />
    <preference name="android-build-tool" value="gradle" />
</platform>
```

### Required Permissions

```xml
<uses-permission android:name="android.permission.INTERNET" />
<uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />
<uses-permission android:name="android.permission.WAKE_LOCK" />
<uses-permission android:name="android.permission.FOREGROUND_SERVICE" />
```

## Would you like me to proceed with creating the Android app?

Let me know which approach you prefer:
1. **Cordova conversion** (fastest, uses existing web code)
2. **React Native app** (more native features)
3. **Flutter app** (best performance, modern UI)

I can start building whichever option you choose!